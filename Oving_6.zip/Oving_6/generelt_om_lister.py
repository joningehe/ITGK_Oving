#a
my_first_list = [1, 2, 3, 4, 5, 6]
#b
print(my_first_list[5])
print(len(my_first_list))
#c
my_first_list[4] = 'pluss'
print(my_first_list)
#d
my_second_list = my_first_list[3:6]
#e
print(my_second_list, 'er lik 10')
