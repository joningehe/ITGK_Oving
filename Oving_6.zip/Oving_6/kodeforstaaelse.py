#A)
#Funksjonen finner en variabel som består av 1 mindre enn lengden, til listen og returnerer verdier for den første halvdelen av listen.

#B)
#Ta inn liste a, opprettet liste b, velger et tilfeldig tall i liste a, legger til i b og sletter fra a, looper til lengden av a er doneself.

#C)
#Listen printer alt fra -2-ende posisjon, altså 7, til 6 posisjon, 7, så kun 7.

#D)
#Må bare endre fra () til []
#navn = ['Carina', 'erik', 'Magnus', 'Miriam']
#navn[1] = 'Erik'
#print(navn)

#E)
# liste1 sorteres fra 1-6 i stigende rekkefølge.
# liste 1 og liste 2 legges sammen slik man får en liste fra 1-9.
# liste 3 består av liste1 og 2, hvor 1 er fjernet og 10 er satt inn bak 9
# listen reverseres så den går i syneknde rekkefølge fra 10 -> 2, 1 er fjernet
